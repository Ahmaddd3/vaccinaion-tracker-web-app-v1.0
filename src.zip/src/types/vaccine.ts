import { VaccineTypes } from "./enums";

export interface Vaccine {
    
    id?: number;
    name?: string; 
    producer?: string;
    vaccineType?: VaccineTypes | null;
    vaccinationType?: string;
    requiredDoses?: number | null;
    user: object;
    userId?: number;
}

