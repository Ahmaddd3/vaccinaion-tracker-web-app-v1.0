
export interface Vaccination {
    id?: number;  // ID der Impfung
    name?: string;  // Name des Impfstoffs
    vaccinationDate?: string;  // Datum der Impfung
    doctorName?: string;  // Arztname
    boosterDate?: string;  // Optionales Auffrischungsdatum
    serialNumber?: string;  // Optional: Seriennummer
    manufacturingDate?: string;  // Optional: Herstellungsdatum
    user: object;
    vaccine: object;
    userId?: number;  // ID des zugehörigen Benutzers
    vaccineId?: number;  // ID des zugehörigen Impfstoffs
}
