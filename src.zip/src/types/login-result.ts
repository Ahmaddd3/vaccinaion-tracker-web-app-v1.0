
interface LoginResult {
    token: string;
    uid: string;
}