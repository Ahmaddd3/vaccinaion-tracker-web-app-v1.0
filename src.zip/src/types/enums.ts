
export enum InsuranceTypes {
  PrivateInsurance = 0,
  Government = 1,
}

export enum VaccineTypes {
  mRNA = 0,
  Vector = 1,
  ProteinSubunit = 2,
  InactivatedVirus = 3,
}
