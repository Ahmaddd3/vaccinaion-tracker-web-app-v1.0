import { InsuranceTypes } from "./enums";

export interface User {
    id: number;
    email?: string;
    passwordHash?: string;
    firstName?: string;
    lastName?: string;
    street?: string;
    houseNumber?: string;
    zipCode?: string;
    city?: string;
    phoneNumber?: string;
    healthInsurance?: string;
    insuranceType?: InsuranceTypes | null;

}