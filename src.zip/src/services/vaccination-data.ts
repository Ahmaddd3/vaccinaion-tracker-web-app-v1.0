

import { Vaccination } from "@/types/vaccination";

const rootUrl = "https://localhost:7064/api";

// Add Vaccination (angepasst für das Backend)
export const addVaccination = async (token: string, vaccination: Vaccination): Promise<Vaccination> => {
    
    const response = await fetch(`${rootUrl}/Vaccination`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`, // Authorization-Header mit Token
        },
        body: JSON.stringify(vaccination), // Impfungsdaten als JSON im Body
    });

    if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(
            response.status === 404 ? "No vaccines found" : errorMessage || "Request failed"
        );
    }

    const responseData = await response.json();
    return responseData; // Rückgabe der hinzugefügten Impfung

};

// Get Vaccinations (angepasst für das Backend)
export const getVaccinations = async (token: string, userId: number): Promise<Vaccination[]> => {
    
    const response = await fetch(`${rootUrl}/Vaccination/${userId}`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`, // Authorization-Header mit Token
        },
    });

    if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(
            response.status === 404 ? "No vaccines found" : errorMessage || "Request failed"
        );
    }

    const vaccinations: Vaccination[] = await response.json();
    return vaccinations; // Rückgabe der Impfungen

};

export const updateVaccination = async (token: string, id: number, vaccination: Partial<Vaccination>): Promise<Vaccination> => {
    const response = await fetch(`${rootUrl}/Vaccination/${id}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify(vaccination),
    });

    if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(
            response.status === 400 ? "BadRequest" : errorMessage || "Request failed"
        );
    }

    return await response.json();
};

export const deleteVaccination = async (token: string, id: number): Promise<void> => {
    const response = await fetch(`${rootUrl}/Vaccination/${id}`, {
        method: "DELETE",
        headers: {
            "Authorization": `Bearer ${token}`,
        },
    });

    if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(
            response.status === 400 ? "BadRequest" : errorMessage || "Request failed"
        );
    }
};
