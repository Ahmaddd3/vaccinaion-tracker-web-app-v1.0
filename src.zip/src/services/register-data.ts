import { User } from "../types/user";

const rootUrl = "https://localhost:7064/api/Auth/register"; 

export const postUser = async (data: { email: string, password: string }): Promise<User> => {
    const response = await fetch(`${rootUrl}`, {
        method: "POST",
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json",  // Stelle sicher, dass der Content-Type gesetzt ist
        },
        body: JSON.stringify(data),  // Sende die Daten als JSON im Body
    });

    if (!response.ok) {
        throw new Error("Registration failed");
    }

    const responseData = await response.json();
    return responseData.user;  // Gebe die Benutzerdaten zurück
};
