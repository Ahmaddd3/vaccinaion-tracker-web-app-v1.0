

export const loginUser = async (credentials: LoginRequest) : Promise<LoginResult>=> {
    const response = await fetch('https://localhost:7064/api/Auth/login', {
        method: "POST",
        headers: { 
            "accept": "*/*",
            "Content-Type": "application/json" 
        },
        body: JSON.stringify(credentials) 
    });

    if (!response.ok) { 
        throw new Error("Login failed");
    }

    return response.json(); 
};

