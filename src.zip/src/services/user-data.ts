import { User } from "@/types/user";

const rootUrl = "https://localhost:7064/api";

export const getUser = async (token: string): Promise<User> => {
    const response = await fetch(`${rootUrl}/User`, {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Authorization": `Bearer ${token}`,
        },
    });

    if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(
            response.status === 400 ? "BadRequest" : errorMessage || "Request failed"
        );
    }
    const responseData = await response.json();
    return responseData.user;
};

export const updateUser = async (token: string, user: User): Promise<User> => {
    const response = await fetch(`${rootUrl}/User`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify(user),
    });

    if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(
            response.status === 400 ? "BadRequest" : errorMessage || "Request failed"
        );
    }
    const responseData = await response.json();
    return responseData.user;
};
