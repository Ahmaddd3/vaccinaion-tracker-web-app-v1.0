import { Vaccine } from "@/types/vaccine";

const rootUrl = "https://localhost:7064/api";

export const addVaccine = async (token: string, vaccine: Vaccine): Promise<Vaccine[]> => {
    const response = await fetch(`${rootUrl}/Vaccine`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify(vaccine),
    });
    console.log(vaccine);
    if (!response.ok) {
        const errorMessage = await response.text();
        throw new Error(
            response.status === 400 ? "BadRequest" : errorMessage || "Request failed"
        );
    }

    const responseData = await response.json();
    return responseData;
};

export const getVaccines = async (token: string, userId: number): Promise<Vaccine[]> => {
    if (!token) {
        throw new Error("Authorization token is missing");
    }

    try {
        const response = await fetch(`${rootUrl}/Vaccine/${userId}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            },
        });

        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(
                response.status === 404
                    ? "No vaccines found"
                    : response.status === 401
                    ? "Unauthorized: Please log in again."
                    : errorMessage || "Request failed"
            );
        }

        const vaccines: Vaccine[] = await response.json();
        if (!Array.isArray(vaccines)) {
            throw new Error("Unexpected response format for vaccines");
        }

        return vaccines;
    } catch (error: any) {
        console.error("Error fetching vaccines:", error.message);
        throw new Error(error.message || "Failed to fetch vaccines");
    }
};

