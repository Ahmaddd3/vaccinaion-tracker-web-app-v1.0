"use client";

import { useState, useEffect } from "react";
import { addVaccine } from "@/services/vaccine-data"; // Import addVaccine function
import { useRouter } from "next/navigation";
import { VaccineTypes } from "@/types/enums";
import { User } from "@/types/user";
import { Vaccine } from "@/types/vaccine";
import { getUser } from "@/services/user-data"; // Import getUser function

export default function VaccinePage() {
    const [user, setUser] = useState<any>(null);
    const [name, setName] = useState("");
    const [id, setId] = useState("");
    const [producer, setProducer] = useState("");
    const [vaccineType, setVaccineType] = useState<VaccineTypes | "">("");
    const [vaccinationType, setVaccinationType] = useState("");
    const [requiredDoses, setRequiredDoses] = useState<number | "">("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();
    
    useEffect(() => {
        const token = localStorage.getItem("token");
       
        if (!token) {
            router.push("/login");
            return;
        }

        const fetchUser = async () => {
            try {
                const userData = await getUser(token);
                setUser(userData);
            } catch (err: any) {
                console.error("Error fetching user data:", err);
                localStorage.removeItem("token");
                router.push("/login");
            }
        };

        fetchUser();
    }, [router]);

    const handleLogout = () => {
        localStorage.removeItem("token");
        router.push("/login");
    };

    const handleAddVaccine = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setLoading(true); // Ladezustand aktivieren

        try {
            const token = localStorage.getItem("token");
            if (!token) {
                setError("Authentication token is missing.");
                return;
            }
            const userT ={ vaccinations:[]};
            const vaccine: Vaccine = {
                userId: user.id,
                user: userT,
                name,
                producer,
                vaccineType: vaccineType || null,
                vaccinationType,
                requiredDoses: requiredDoses === "" ? undefined : Number(requiredDoses),
            };
            
            console.log("Sending vaccine data:", vaccine);            
            
            await addVaccine(token, vaccine);
            alert("Vaccine added successfully!");

            // Formular zurücksetzen
            setId("");
            setName("");
            setProducer("");
            setVaccineType("");
            setVaccinationType("");
            setRequiredDoses("");

            router.push("/showVaccines");
        } catch (error) {
            console.error("Error adding vaccine:", error);
            setError("Failed to add vaccine. Please try again.");
        } finally {
            setLoading(false); // Ladezustand deaktivieren
        }
    };
    

    return (
        <div className="min-h-screen text-black bg-gray-100 py-10">
            <div className="max-w-4xl mx-auto bg-white shadow rounded-lg p-6">
                <h1 className="text-2xl font-bold text-center">Add New Vaccine</h1>

                {loading && <p className="text-center text-gray-500">Submitting...</p>}
                {error && <p className="text-center text-red-500">{error}</p>}

                <form onSubmit={handleAddVaccine} className="space-y-4 mt-6">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700">Vaccine Name</label>
                        <input
                            id="name"
                            type="text"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                                setError(null); // Fehler zurücksetzen
                            }}
                            className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                            required
                        />
                    </div>

                    <div>
                        <label htmlFor="producer" className="block text-sm font-medium text-gray-700">Producer</label>
                        <input
                            id="producer"
                            type="text"
                            value={producer}
                            onChange={(e) => {
                                setProducer(e.target.value);
                                setError(null); // Fehler zurücksetzen
                            }}
                            className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                            required
                        />
                    </div>

                    <div>
                        <label htmlFor="vaccineType" className="block text-sm font-medium text-gray-700">Vaccine Type</label>
                        <select
                            id="vaccineType"
                            value={vaccineType}
                            onChange={(e) => {
                                const value = parseInt(e.target.value, 10); // Parse as number for numeric enums
                            
                                if (Object.values(VaccineTypes).includes(value)) {
                                    setVaccineType(value as VaccineTypes); // Set the vaccine type if valid
                                } else {
                                    setVaccineType(""); // Reset if invalid
                                }
                                setError(null); // Reset error
                            }}
                            
                            className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                        >
                        <option value="">Select Type</option>
                            {Object.keys(VaccineTypes)
                                .filter((key) => isNaN(Number(key))) // Filter out numeric keys
                                .map((key, index) => {
                                    const value = VaccineTypes[key as keyof typeof VaccineTypes]; // Get the value associated with the key
                                    return (
                                        <option key={`${key}-${value}-${index}`} value={value}>
                                            {key} 
                                        </option>
                                    );
                                })}

                        </select>
                    </div>

                    <div>
                        <label htmlFor="vaccinationType" className="block text-sm font-medium text-gray-700">Vaccination Type</label>
                        <input
                            id="vaccinationType"
                            type="text"
                            value={vaccinationType}
                            onChange={(e) => {
                                setVaccinationType(e.target.value);
                                setError(null); // Fehler zurücksetzen
                            }}
                            className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                            required
                        />
                    </div>

                    <div>
                        <label htmlFor="requiredDoses" className="block text-sm font-medium text-gray-700">Required Doses</label>
                        <input
                            id="requiredDoses"
                            type="number"
                            value={requiredDoses}
                            onChange={(e) => {
                                setRequiredDoses(e.target.value === "" ? "" : Number(e.target.value));
                                setError(null); // Fehler zurücksetzen
                            }}
                            className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={loading}
                        className={`w-full py-2 px-4 text-white rounded ${
                            loading ? "bg-gray-400 cursor-not-allowed" : "bg-blue-500 hover:bg-blue-600"
                        }`}
                    >
                        {loading ? "Submitting..." : "Add Vaccine"}
                    </button>
                </form>

                {/* Home Button */}
                <div className="absolute top-4 left-4">
                    <button
                        onClick={() => router.push("/dashboard")}
                        className="bg-blue-500 text-white px-4 py-2 rounded shadow hover:bg-blue-600"
                    >
                        Home
                    </button>
                </div>

                <div className="absolute top-6 right-6">
                    <button
                        onClick={handleLogout}
                        className="px-5 py-3 bg-red-600 text-white font-bold text-lg rounded-lg shadow-lg hover:bg-red-700"
                    >
                        Logout
                    </button>
                </div>
            </div>
        </div>
    );
}
