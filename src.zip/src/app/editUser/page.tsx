"use client";

import { InsuranceTypes } from "@/types/enums"; // Import the InsuranceTypes enum
import { useEffect, useState } from "react";
import { getUser, updateUser } from "@/services/user-data";
import { User } from "@/types/user";
import { useRouter } from "next/navigation";

export default function HomePage() {
    const [user, setUser] = useState<User | null>(null);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();

    // Fetch user data on component mount
    useEffect(() => {
        const fetchUser = async () => {
            try {
                const token = localStorage.getItem("token");
                if (!token) {
                    router.push("/login");
                    return;
                }

                const userData = await getUser(token);
                setUser(userData);
            } catch (err: any) {
                console.error("Error fetching user data:", err);
                if (err.message === "BadRequest" || err.response?.status === 400) {
                    localStorage.removeItem("token");
                    router.push("/login");
                } else {
                    setError(err.message || "Failed to fetch user data.");
                }
            }
        };

        fetchUser();
    }, [router]);

    // Handle input changes for text and select fields
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;

        setUser((prevUser) =>
            prevUser
                ? {
                      ...prevUser,
                      [name]: name === "insuranceType" ? parseInt(value, 10) : value, // Parse insuranceType as a number
                  }
                : null
        );
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        router.push("/login");
    };

    // Handle form submission
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if (!user) {
            setError("No user data to save.");
            return;
        }

        console.log("Submitting user data:", user); // Debugging log

        try {
            const token = localStorage.getItem("token");
            if (!token) {
                setError("Authentication token is missing.");
                return;
            }

            await updateUser(token, user);
            alert("User data saved successfully!");
        } catch (err: any) {
            console.error("Error saving user data:", err);
            setError(err.message || "Failed to save user data.");
        }
    };

    // Generate InsuranceType options dynamically
    const InsuranceTypeOptions = Object.entries(InsuranceTypes)
        .filter(([key]) => isNaN(Number(key))) // Filter out numeric enum keys
        .map(([key, value]) => ({ label: key, value }));

    return (
        <div className="flex items-center justify-center min-h-screen">
            <form
                className="w-1/3 bg-white p-6 rounded shadow-md"
                onSubmit={handleSubmit}
                
            >
                {/* First Name Input */}
                <label className="block text-sm font-medium text-gray-700">
                    First Name
                    <input
                        type="text"
                        name="firstName"
                        value={user?.firstName || ""}
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                        placeholder="Enter first name"
                    />
                </label>
                
                {/* Home Button */}
                <div className="absolute top-4 left-4">
                    <button
                        onClick={() => router.push("/dashboard")}
                        className="bg-blue-500 text-white px-4 py-2 rounded shadow hover:bg-blue-600"
                    >
                        Home
                    </button>
                </div>
                
                <div className="absolute top-6 right-6">
                <button
                    onClick={handleLogout}
                    className="px-5 py-3 bg-red-600 text-white font-bold text-lg rounded-lg shadow-lg hover:bg-red-700"
                >
                    Logout
                </button>
                </div>

                {/* Last Name Input */}
                <label className="block text-sm font-medium text-gray-700 mt-4">
                    Last Name
                    <input
                        type="text"
                        name="lastName"
                        value={user?.lastName || ""}
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                        placeholder="Enter last name"
                    />
                </label>

                {/* Street Input */}
                <label className="block text-sm font-medium text-gray-700 mt-4">
                    Street
                    <input
                        type="text"
                        name="street"
                        value={user?.street || ""}
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                        placeholder="Enter street"
                    />
                </label>

                {/* House Number Input */}
                <label className="block text-sm font-medium text-gray-700 mt-4">
                    House Number
                    <input
                        type="text"
                        name="houseNumber"
                        value={user?.houseNumber || ""}
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                        placeholder="Enter house number"
                    />
                </label>

                {/* Zip Code Input */}
                <label className="block text-sm font-medium text-gray-700 mt-4">
                    Zip Code
                    <input
                        type="text"
                        name="zipCode"
                        value={user?.zipCode || ""}
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                        placeholder="Enter zip code"
                    />
                </label>

                {/* City Input */}
                <label className="block text-sm font-medium text-gray-700 mt-4">
                    City
                    <input
                        type="text"
                        name="city"
                        value={user?.city || ""}
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                        placeholder="Enter city"
                    />
                </label>

                {/* Phone Number Input */}
                <label className="block text-sm font-medium text-gray-700 mt-4">
                    Phone Number
                    <input
                        type="text"
                        name="phoneNumber"
                        value={user?.phoneNumber || ""}
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                        placeholder="Enter phone number"
                    />
                </label>

                {/* Email Input */}
                <label className="block text-sm font-medium text-gray-700 mt-4">
                    Email
                    <input
                        type="email"
                        name="email"
                        value={user?.email || ""}
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                        placeholder="Enter email"
                    />
                </label>

                {/* Health Insurance Input */}
                <label className="block text-sm font-medium text-gray-700 mt-4">
                    Health Insurance
                    <input
                        type="text"
                        name="healthInsurance"
                        value={user?.healthInsurance || ""}
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                        placeholder="Enter health insurance"
                    />
                </label>

                {/* Insurance Type Select */}
                <label className="block text-sm font-medium text-gray-700 mt-4">
                    Insurance Type
                    <select
                        name="insuranceType"
                        value={user?.insuranceType ?? ""} // Ensure default value is handled
                        onChange={handleInputChange}
                        className="w-full mt-1 p-2 border rounded focus:ring focus:ring-blue-300"
                    >
                        <option value="">Select insurance type</option>
                        {InsuranceTypeOptions.map((option) => (
                            <option key={option.value} value={option.value}>
                                {option.label}
                            </option>
                        ))}
                    </select>
                </label>

                {/* Submit Button */}
                <button
                    type="submit"
                    className="w-full bg-blue-500 text-white py-2 rounded mt-4 hover:bg-blue-600"
                >
                    Save Changes
                </button>

                {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
            </form>
        </div>
    );
}
