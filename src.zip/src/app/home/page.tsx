"use client";

import { useEffect, useState } from "react";
import { getUser } from "@/services/user-data";
import { User } from "@/types/user";
import { useRouter } from "next/navigation";

export default function HomePage() {
    const [user, setUser] = useState<User | null>(null);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const token = localStorage.getItem("token");
                if (!token) {
                    router.push("/login"); // Redirect if no token
                    return;
                }

                const userData = await getUser(token);
                setUser(userData);
            } catch (err: any) {
                console.error("Error fetching user data:", err);
                if (err.response?.status === 400 || err.message === "BadRequest") {
                    localStorage.removeItem("token");
                    router.push("/login");
                } else {
                    setError(err.message || "Failed to fetch user data.");
                }
            }
        };

        fetchUser();
    }, []);

    if (error) {
        return (
            <div className="flex min-h-screen items-center justify-center">
                <p className="text-red-500">{error}</p>
            </div>
        );
    }

    return (
        <div className="relative flex items-center justify-center min-h-screen bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
            {/* Background Text */}
            <h1 className="absolute inset-0 flex items-center justify-center text-[6rem] font-extrabold opacity-10 select-none">
                Vaccine Tracker
            </h1>

            {/* Foreground Content */}
            <div className="z-10 flex flex-col items-center space-y-8">
                {/* If user is logged in */}
                {user ? (
                    <>
                        <h2 className="text-4xl font-bold">Welcome, {user.firstName}!</h2>
                        <p className="text-lg">Track and manage your vaccinations with ease.</p>
                    </>
                ) : (
                    <>
                        <h2 className="text-4xl font-bold">Welcome to Vaccine Tracker</h2>
                        <p className="text-lg">Track and manage your vaccinations with ease!</p>
                        <div className="flex space-x-4">
                            <button
                                onClick={() => router.push("/login")}
                                className="px-6 py-3 text-lg font-semibold bg-white text-indigo-600 rounded-lg shadow-md hover:bg-gray-100"
                            >
                                Login
                            </button>
                            <button
                                onClick={() => router.push("/register")}
                                className="px-6 py-3 text-lg font-semibold bg-white text-indigo-600 rounded-lg shadow-md hover:bg-gray-100"
                            >
                                Register
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}
