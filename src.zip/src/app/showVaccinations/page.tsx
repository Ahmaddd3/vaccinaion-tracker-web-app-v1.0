"use client";

import { useState, useEffect } from "react";
import { getVaccinations, updateVaccination, deleteVaccination } from "@/services/vaccination-data";
import { useRouter } from "next/navigation";
import { Vaccination } from "@/types/vaccination";

export default function ShowVaccinationsPage() {
    const [vaccinations, setVaccinations] = useState<Vaccination[]>([]);
    const [currentEdit, setCurrentEdit] = useState<Partial<Vaccination> | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();

    useEffect(() => {
        const fetchVaccinations = async () => {
            try {
                const token = localStorage.getItem("token");
                const userId = localStorage.getItem("uid");

                if (!token || !userId) {
                    router.push("/login");
                    return;
                }

                setLoading(true);
                const vaccinationData = await getVaccinations(token, parseInt(userId));
                setVaccinations(vaccinationData);
            } catch (err: any) {
                console.error("Error fetching vaccinations:", err);
                setError(err.message || "An unknown error occurred.");
            } finally {
                setLoading(false);
            }
        };

        fetchVaccinations();
    }, [router]);

    const handleEditSubmit = async () => {
        if (!currentEdit) return;

        try {
            const token = localStorage.getItem("token");
            if (!token) {
                throw new Error("Token missing");
            }

            const originalVaccination = vaccinations.find(v => v.id === currentEdit.id);
            if (!originalVaccination) {
                throw new Error("Original vaccination not found");
            }

            const updatedVaccination = { ...originalVaccination, ...currentEdit };

            if (updatedVaccination.id === undefined) {
                throw new Error("Vaccination ID is undefined");
            }
            const updated = await updateVaccination(token, updatedVaccination.id, updatedVaccination);

            setVaccinations(vaccinations.map(v =>
                v.id === updated.id ? updated : v
            ));

            setCurrentEdit(null);
        } catch (err: any) {
            console.error("Error updating vaccination:", err);
            setError(err.message || "An unknown error occurred.");
        }
    };

    const handleDelete = async (id: number) => {
        try {
            const token = localStorage.getItem("token");
            if (!token) {
                throw new Error("Token missing");
            }

            await deleteVaccination(token, id);

            setVaccinations(vaccinations.filter(v => v.id !== id));
        } catch (err: any) {
            console.error("Error deleting vaccination:", err);
            setError(err.message || "An unknown error occurred.");
        }
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        router.push("/login");
    };

    return (
        <div className="min-h-screen text-black bg-gray-100 py-10">
            {/* Home Button */}
            <div className="absolute top-4 left-4">
                <button
                    onClick={() => router.push("/dashboard")}
                    className="bg-blue-500 text-white px-4 py-2 rounded shadow hover:bg-blue-600"
                >
                    Home
                </button>
            </div>

            <div className="absolute top-6 right-6">
                <button
                    onClick={handleLogout}
                    className="px-5 py-3 bg-red-600 text-white font-bold text-lg rounded-lg shadow-lg hover:bg-red-700"
                >
                    Logout
                </button>
            </div>

            <div className="max-w-4xl mx-auto bg-white shadow rounded-lg p-6">
                <h1 className="text-2xl font-bold text-center">Vaccinations List</h1>

                {loading && <p className="text-center text-gray-500">Loading...</p>}

                {error && <p className="text-center text-red-500">{error}</p>}

                {!loading && !error && (
                    <div>
                        {vaccinations.length > 0 ? (
                            <ul className="space-y-4">
                                {vaccinations.map((vaccination) => (
                                    <li
                                        key={vaccination.id}
                                        className="border p-4 rounded-lg shadow-sm"
                                    >
                                        {currentEdit?.id === vaccination.id ? (
                                            <div>
                                                <input
                                                    type="text"
                                                    defaultValue={vaccination.name}
                                                    onChange={(e) =>
                                                        setCurrentEdit({
                                                            ...currentEdit,
                                                            name: e.target.value,
                                                        })
                                                    }
                                                    className="border p-2 w-full rounded"
                                                />
                                                <button
                                                    onClick={handleEditSubmit}
                                                    className="bg-green-500 text-white px-4 py-2 rounded mt-2"
                                                >
                                                    Save
                                                </button>
                                                <button
                                                    onClick={() => setCurrentEdit(null)}
                                                    className="bg-gray-500 text-white px-4 py-2 rounded mt-2 ml-2"
                                                >
                                                    Cancel
                                                </button>
                                            </div>
                                        ) : (
                                            <div>
                                                <h3 className="text-xl font-semibold">
                                                    {vaccination.name || "Unknown Vaccine"}
                                                </h3>
                                                <p><strong>Doctor:</strong> {vaccination.doctorName}</p>
                                                <p><strong>Vaccination Date:</strong> {vaccination.vaccinationDate}</p>
                                                <button
                                                    onClick={() => setCurrentEdit(vaccination)}
                                                    className="bg-blue-500 text-white px-4 py-2 rounded mt-2"
                                                >
                                                    Edit
                                                </button>
                                                <button
                                                    onClick={() => vaccination.id !== undefined && handleDelete(vaccination.id)}
                                                    className="bg-red-500 text-white px-4 py-2 rounded mt-2 ml-2"
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        )}
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-center text-gray-500">No vaccinations found.</p>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
