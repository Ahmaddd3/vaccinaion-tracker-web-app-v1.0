"use client";

import { useEffect, useState } from "react";
import { getUser } from "@/services/user-data";
import { User } from "@/types/user";
import { useRouter } from "next/navigation";

export default function HomePage() {
    const [user, setUser] = useState<User | null>(null);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const token = localStorage.getItem("token");
                if (!token) {
                    window.location.href = "/login";
                    return;
                }

                const userData = await getUser(token);
                setUser(userData);
            } catch (err: any) {
                console.error("Error fetching user data:", err);
                if (err.response?.status === 400 || err.message === "BadRequest") {
                    localStorage.removeItem("token");
                    window.location.href = "/login";
                } else {
                    setError(err.message || "Failed to fetch user data.");
                }
            }
        };

        fetchUser();
    }, []);

    const handleEditRedirect = () => {
        if (user) {
            router.push(`/editUser?userData=${encodeURIComponent(JSON.stringify(user))}`);
        } else {
            console.error("User data is not available for redirection.");
        }
    };

    const handleAddVaccination = () => {
        router.push("/vaccination");
    };

    const handleAddVaccine = () => {
        router.push("/vaccine");
    };

    const handleShowVaccines = () => {
        router.push("/showVaccines");
    };

    const handleShowVaccinations = () => {
        router.push("/showVaccinations");
    };
    
    const handleReminder = () => {
        router.push("/Reminder");
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        router.push("/login");
    };

    if (error) {
        return (
            <div className="flex min-h-screen items-center justify-center">
                <p className="text-red-500">{error}</p>
            </div>
        );
    }

    return (
        <div
            className="flex flex-col min-h-screen items-center justify-center space-y-6 bg-cover bg-center text-white"
            style={{
                backgroundImage: `url('/images/background.jpg')`,
                backgroundSize: "cover",
                backgroundPosition: "center",
            }}
        >
            <div className="absolute top-6 right-6">
                <button
                    onClick={handleLogout}
                    className="px-5 py-3 bg-red-600 text-white font-bold text-lg rounded-lg shadow-lg hover:bg-red-700"
                >
                    Logout
                </button>
            </div>
            <div className="absolute top-6 left-6">
                <button
                    onClick={handleReminder}
                    className="px-5 py-3 bg-yello-600 text-white font-bold text-lg rounded-lg shadow-lg hover:bg-green-700"
                >
                    Push to remember Booster :) 
                </button>
            </div>
            <h1 className="text-4xl font-extrabold drop-shadow-lg">
                Welcome, {user?.firstName || "Guest"}
            </h1>
            <button
                onClick={handleAddVaccination}
                className="px-6 py-3 bg-green-600 text-white font-semibold text-lg rounded-lg shadow-md hover:bg-green-700"
            >
                Add Vaccination
            </button>
            <button
                onClick={handleAddVaccine}
                className="px-6 py-3 bg-yellow-600 text-white font-semibold text-lg rounded-lg shadow-md hover:bg-yellow-700"
            >
                Add Vaccine
            </button>
            <button
                onClick={handleShowVaccinations}
                className="px-6 py-3 bg-teal-600 text-white font-semibold text-lg rounded-lg shadow-md hover:bg-teal-700"
            >
                Show Vaccinations
            </button>
            <button
                onClick={handleShowVaccines}
                className="px-6 py-3 bg-purple-600 text-white font-semibold text-lg rounded-lg shadow-md hover:bg-purple-700"
            >
                Show Vaccines
            </button>
            <button
                onClick={handleEditRedirect}
                className="px-6 py-3 bg-blue-600 text-white font-semibold text-lg rounded-lg shadow-md hover:bg-blue-700"
            >
                Edit User Data
            </button>
        </div>
    );
}
