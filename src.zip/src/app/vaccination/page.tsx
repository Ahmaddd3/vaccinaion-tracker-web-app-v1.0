"use client";

import { useState, useEffect, FormEvent } from "react";
import { addVaccination } from "@/services/vaccination-data";
import { getVaccines } from "@/services/vaccine-data";
import { getUser } from "@/services/user-data";
import { useRouter } from "next/navigation";
import { Vaccination } from "@/types/vaccination";
import { Vaccine } from "@/types/vaccine";
import { User } from "@/types/user";

export default function VaccinationPage() {
    const [doctor, setDoctor] = useState("");
    const [date, setDate] = useState("");
    const [boosterDate, setBoosterDate] = useState<string | null>(""); // Handle booster date as string or null
    const [serialNumber, setSerialNumber] = useState<string>(""); // Handle serial number
    const [manufacturingDate, setManufacturingDate] = useState<string>(""); // Handle manufacturing date as string
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [vaccines, setVaccines] = useState<Vaccine[]>([]); // Vaccine list
    const [selectedVaccine, setSelectedVaccine] = useState<string>(""); // Selected vaccine name
    const [selectedVaccineId, setSelectedVaccineId] = useState<number | undefined>(undefined);
    const [user, setUser] = useState<any>(null);
    const router = useRouter();

    useEffect(() => {
        const fetchUserAndVaccines = async () => {
            try {
                const token = localStorage.getItem("token");
                if (!token) {
                    router.push("/login");
                    return;
                }

                // Fetch user data
                const userData = await getUser(token);
                setUser(userData);

                // Fetch vaccines
                const vaccineList = await getVaccines(token, userData.id);
                setVaccines(vaccineList);
            } catch (error: any) {
                console.error("Error fetching data:", error);
                setError(error.message || "Failed to fetch data.");
            }
        };

        fetchUserAndVaccines();
    }, []);

    const handleLogout = () => {
        localStorage.removeItem("token");
        router.push("/login");
    };

    async function handleAddVaccination(event: FormEvent<HTMLFormElement>): Promise<void> {
        event.preventDefault();
        setLoading(true);
        try {
            const token = localStorage.getItem("token");
            if (!token) {
                alert("You must be logged in to add a vaccine.");
                setLoading(false);
                return;
            }

            const vaccination: Vaccination = {
                name: selectedVaccine,
                vaccinationDate: date,
                doctorName: doctor,
                boosterDate: boosterDate || undefined,
                serialNumber: serialNumber || undefined,
                manufacturingDate: manufacturingDate || undefined,
                userId: user.id, // userId from the fetched user data
                vaccineId: selectedVaccineId, // vaccineId from the selected vaccine
                user: {
                    vaccinations: [] // Empty vaccinations array for user
                },
                vaccine: {
                    vaccinations: [], // Empty vaccinations array for vaccine
                    userId: user.id, // userId for the vaccine
                    user: {
                        vaccinations: [] // Empty vaccinations array for vaccine's user
                    }
                }
            };

            console.log("Sending vaccination data:", vaccination);

            const addedVaccination = await addVaccination(token, vaccination);

            alert("Vaccination added successfully!");
            console.log("Added Vaccination:", addedVaccination);

            // Reset all fields after successful submission
            setDoctor("");
            setDate("");
            setBoosterDate(null);
            setSerialNumber("");
            setManufacturingDate("");
            setSelectedVaccine("");
            setSelectedVaccineId(undefined);

            router.push("/showVaccinations");
        } catch (error: any) {
            console.error("Error occurred while adding vaccination:", error);
            alert(error.message || "Failed to add vaccination.");
            setError(error.message || "Failed to add vaccination.");
        } finally {
            setLoading(false);
        }
    }

    return (
        <div className="flex min-h-screen items-center text-black justify-center bg-gray-100">
            <form
                onSubmit={handleAddVaccination}
                className="space-y-4 p-6 bg-white shadow rounded w-full max-w-md"
            >
                <h1 className="text-xl font-bold text-center">Add Vaccination</h1>
                {/* Home Button */}
                <div className="absolute top-4 left-4">
                    <button
                        onClick={() => router.push("/dashboard")}
                        className="bg-blue-500 text-white px-4 py-2 rounded shadow hover:bg-blue-600"
                    >
                        Home
                    </button>
                </div>
                {/* Logout Button */}
                <div className="absolute top-6 right-6">
                    <button
                        onClick={handleLogout}
                        className="text-red-600 font-semibold"
                    >
                        Logout
                    </button>
                </div>
                {/* Dropdown for selecting vaccination name */}
                <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                        Vaccine Name
                    </label>
                    <select
                        id="name"
                        value={selectedVaccine}
                        onChange={(e) => {
                            setSelectedVaccine(e.target.value);
                            const vaccine = vaccines.find(v => v.name === e.target.value);
                            setSelectedVaccineId(vaccine ? vaccine.id : undefined);
                        }}
                        className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                        required
                    >
                        <option value="">Select a Vaccine</option>
                        {vaccines.map((vaccine, index) => (
                            <option key={vaccine.id || `${vaccine.name}-${index}`} value={vaccine.name}>
                                {vaccine.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label htmlFor="doctor" className="block text-sm font-medium text-gray-700">
                        Doctor
                    </label>
                    <input
                        id="doctor"
                        type="text"
                        value={doctor}
                        onChange={(e) => setDoctor(e.target.value)}
                        className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                        required
                    />
                </div>

                <div>
                    <label htmlFor="date" className="block text-sm font-medium text-gray-700">
                        Vaccination Date
                    </label>
                    <input
                        id="date"
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                        required
                    />
                </div>

                <div>
                    <label htmlFor="boosterDate" className="block text-sm font-medium text-gray-700">
                        Booster Date 
                    </label>
                    <input
                        id="boosterDate"
                        type="date"
                        value={boosterDate || ""}
                        onChange={(e) => setBoosterDate(e.target.value || null)}
                        className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                    />
                </div>

                <div>
                    <label htmlFor="serialNumber" className="block text-sm font-medium text-gray-700">
                        Serial Number 
                    </label>
                    <input
                        id="serialNumber"
                        type="text"
                        value={serialNumber}
                        onChange={(e) => setSerialNumber(e.target.value)}
                        className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                    />
                </div>

                <div>
                    <label htmlFor="manufacturingDate" className="block text-sm font-medium text-gray-700">
                        Manufacturing Date 
                    </label>
                    <input
                        id="manufacturingDate"
                        type="date"
                        value={manufacturingDate || ""}
                        onChange={(e) => setManufacturingDate(e.target.value)}
                        className="mt-1 p-2 w-full border rounded focus:ring focus:ring-blue-300"
                    />
                </div>

                <button
                    type="submit"
                    disabled={loading}
                    className={`w-full py-2 px-4 text-white rounded ${loading ? "bg-gray-400 cursor-not-allowed" : "bg-blue-500 hover:bg-blue-600"}`}
                >
                    {loading ? "Submitting..." : "Add Vaccination"}
                </button>
            </form>
        </div>
    );
}
