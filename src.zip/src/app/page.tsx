"use client";

import { useRouter } from "next/navigation";

export default function HomePage() {
    const router = useRouter();

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
            <h1 className="text-4xl font-bold mb-6">Welcome to Vaccine Tracker</h1>
            <p className="text-lg text-center mb-8">
                Track your vaccination status easily and securely.
            </p>
            <div className="space-x-4">
                <button
                    onClick={() => router.push("/login")}
                    className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-400"
                >
                    Login
                </button>
                <button
                    onClick={() => router.push("/register")}
                    className="px-6 py-3 bg-yellow-500 text-white rounded-lg hover:bg-yellow-400"
                >
                    Register
                </button>
            </div>
        </div>
    );
}
