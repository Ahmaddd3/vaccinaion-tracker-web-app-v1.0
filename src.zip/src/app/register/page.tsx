"use client";

import { useState, FormEvent } from "react";
import { postUser } from "@/services/register-data";  // Importiere die registrierungsfunktion
import { useRouter } from "next/navigation";

export default function RegisterPage() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();

    async function handleOnSubmit(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();

        try {
            // Verwende hier postUser, um den Benutzer zu registrieren
            await postUser({ email, password }); 
            router.push("/login"); // Weiterleitung zur Login-Seite nach erfolgreicher Registrierung
        } catch (err: any) {
            console.error("Registration failed:", err);
            setError("Registration failed. Please try again.");
        }
    }

    return (
        <div className="flex items-center justify-center min-h-screen bg-gradient-to-r from-green-400 to-teal-500 text-white">
            <div className="w-full max-w-md p-8 bg-white rounded-lg shadow-lg text-gray-800">
                <h2 className="text-3xl font-bold text-center text-green-600">Register</h2>
                <p className="text-center text-gray-500 mb-6">
                    Create your account to track vaccinations.
                </p>
                <form className="space-y-6" onSubmit={handleOnSubmit}>
                    {/* Email Field */}
                    <div>
                        <label className="block text-sm font-medium text-gray-600">Email</label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-4 py-2 mt-1 bg-gray-100 text-gray-700 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none"
                            placeholder="Enter your email"
                        />
                    </div>

                    {/* Password Field */}
                    <div>
                        <label className="block text-sm font-medium text-gray-600">Password</label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-2 mt-1 bg-gray-100 text-gray-700 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none"
                            placeholder="Enter your password"
                        />
                    </div>

                    {/* Error Message */}
                    {error && (
                        <p className="text-sm text-red-500">{error}</p>
                    )}

                    {/* Submit Button */}
                    <button
                        type="submit"
                        className="w-full py-3 text-lg font-semibold text-white bg-green-600 rounded-lg shadow-md hover:bg-green-500 focus:outline-none focus:ring-2 focus:ring-green-400"
                    >
                        Register
                    </button>
                </form>

                {/* Footer */}
                <div className="mt-4 text-center">
                    <p className="text-sm text-gray-500">
                        Already have an account?{" "}
                        <a href="/login" className="text-green-600 hover:underline">
                            Login here
                        </a>
                    </p>
                </div>
            </div>
        </div>
    );
}
