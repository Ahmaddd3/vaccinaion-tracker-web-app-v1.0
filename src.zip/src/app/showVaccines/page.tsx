"use client";

import { useState, useEffect } from "react";
import { getVaccines } from "@/services/vaccine-data"; // Import getVaccines function
import { useRouter } from "next/navigation";
import { Vaccine } from "@/types/vaccine";

export default function ShowVaccinesPage() {
    const [vaccines, setVaccines] = useState<Vaccine[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();
    

    useEffect(() => {
        
        const fetchVaccines = async () => {
            
            try {
                const token = localStorage.getItem("token");
                const userId = localStorage.getItem("uid");
            
                // Überprüfung auf fehlende Authentifizierungsinformationen
                if (!token || !userId) {
                    router.push("/login");
                    return;
                }
                
                const vaccineData = await getVaccines(token, parseInt(userId));
                setVaccines(vaccineData);
            } catch (err: any) {
                console.error("Error fetching vaccines:", err);
                if (err.message === "BadRequest" || err.response?.status === 400) {
                    localStorage.removeItem("token");
                    router.push("/login");
                } else {
                    setError(err.message || "Failed to fetch user data.");
                }
            }
        };
    
        fetchVaccines();
    }, [router]);
    
    const VaccineTypeLabels = {
        0: "mRNA",
        1: "Vector",
        2: "ProteinSubunit",
        3: "InactivatedVirus",
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        router.push("/login");
    };
    
    return (
        <div className="min-h-screen bg-gray-100 py-10">
            {/* Home Button */}
            <div className="absolute top-4 left-4">
                <button
                    onClick={() => router.push("/dashboard")}
                    className="bg-blue-500 text-white px-4 py-2 rounded shadow hover:bg-blue-600"
                >
                    Home
                </button>
            </div>

            <div className="absolute top-6 right-6">
                <button
                    onClick={handleLogout}
                    className="px-5 py-3 bg-red-600 text-white font-bold text-lg rounded-lg shadow-lg hover:bg-red-700"
                >
                    Logout
                </button>
            </div>
            <div className="max-w-4xl mx-auto bg-white shadow rounded-lg p-6">
                <h1 className="text-2xl font-bold text-center text-black">User's Vaccines</h1>
                {loading && <p className="text-center text-black-500">Loading...</p>}
                {error && <p className="text-center text-red-500">{error}</p>}

                {!loading && vaccines.length > 0 ? (
                    <ul>
                    {vaccines.map((vaccine, index) => (
                        <li key={`${vaccine.userId}-${index}`} className="p-4 border-b text-black">
                            <p><strong>Name:</strong> {vaccine.name}</p>
                            <p><strong>Producer:</strong> {vaccine.producer}</p>
                            <p><strong>Type:</strong> {vaccine.vaccineType !== null && vaccine.vaccineType !== undefined ? VaccineTypeLabels[vaccine.vaccineType] : "Unknown"}</p>
                            <p><strong>Doses Required:</strong> {vaccine.requiredDoses}</p>
                        </li>
                    ))}
                </ul>                
                                
                ) : (
                    !loading && <p>No vaccines found.</p>
                )}
            </div>
        </div>
    );
}
