"use client";

import { useEffect, useState } from "react";
import { Vaccination } from "@/types/vaccination";
import { getVaccinations } from "@/services/vaccination-data";
import { useRouter } from "next/navigation";

export default function Reminder() {
    const [upcomingBoosters, setUpcomingBoosters] = useState<Vaccination[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();

    useEffect(() => {
        const fetchBoosterReminders = async () => {
            try {
                const token = localStorage.getItem("token");
                const userId = localStorage.getItem("uid");

                if (!token || !userId) {
                    throw new Error("User is not logged in.");
                }

                const vaccinations = await getVaccinations(token, parseInt(userId));
                const today = new Date();

                // Filter boosters due within the next month
                const boostersDueSoon = vaccinations.filter((vaccination) => {
                    if (!vaccination.boosterDate) return false;
                    const boosterDate = new Date(vaccination.boosterDate);
                    return boosterDate > today && boosterDate <= new Date(today.setMonth(today.getMonth() + 1));
                });

                setUpcomingBoosters(boostersDueSoon);

                if (boostersDueSoon.length > 0) {
                    alert(`There are ${boostersDueSoon.length} vaccinations requiring a booster soon.`);
                }
            } catch (err: any) {
                console.error("Error fetching booster reminders:", err);
                setError(err.message || "An error occurred while checking booster reminders.");
                alert("An error occurred while checking booster reminders.");
            } finally {
                setLoading(false);
            }
        };

        fetchBoosterReminders();
    }, []);

    if (loading) {
        return (
            <div className="p-6 bg-gray-100 rounded-md">
                <p className="text-center text-gray-500 text-xl font-semibold">
                    Loading booster reminders...
                </p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="p-6 bg-red-100 rounded-md">
                <p className="text-center text-red-600 text-xl font-semibold">
                    {error}
                </p>
            </div>
        );
    }

    if (upcomingBoosters.length === 0) {
        return (
            <div className="p-6 bg-gray-100 rounded-md">
                <p className="text-center text-blue-600 text-xl font-semibold">
                    No booster reminders available.
                </p>
            </div>
        );
    }

    const handleLogout = () => {
        localStorage.removeItem("token");
        router.push("/login");
    };

    return (
        <div className="max-w-4xl mx-auto bg-white shadow rounded-lg p-6">

            {/* Home Button */}
            <div className="absolute top-4 left-4">
                <button
                    onClick={() => router.push("/dashboard")}
                    className="bg-blue-500 text-white px-4 py-2 rounded shadow hover:bg-blue-600"
                >
                    Home
                </button>
            </div>
            
            <div className="absolute top-6 right-6">
                <button
                    onClick={handleLogout}
                    className="px-5 py-3 bg-red-600 text-white font-bold text-lg rounded-lg shadow-lg hover:bg-red-700"
                >
                    Logout
                </button>
            </div>

            <h1 className="text-2xl font-bold text-center text-red-800 mb-4">Booster Reminders</h1>
            <ul className="space-y-4">
                {upcomingBoosters.map((vaccination) => (
                    <li
                        key={vaccination.id}
                        className="border p-4 rounded-lg shadow-sm bg-gray-50"
                    >
                        <h3 className="text-xl font-semibold text-green-800">
                            {vaccination.name || "Unknown Vaccine"}
                        </h3>
                        <p className="text-gray-700">
                            <strong>Doctor:</strong> {vaccination.doctorName || "Unknown"}
                        </p>
                        <p className="text-gray-700">
                            <strong>Booster due on:</strong>{" "}
                            {new Date(vaccination.boosterDate!).toLocaleDateString("en-US")}
                        </p>
                        {vaccination.serialNumber && (
                            <p className="text-gray-700">
                                <strong>Serial Number:</strong> {vaccination.serialNumber}
                            </p>
                        )}
                    </li>
                ))}
            </ul>
        </div>
    );
}
