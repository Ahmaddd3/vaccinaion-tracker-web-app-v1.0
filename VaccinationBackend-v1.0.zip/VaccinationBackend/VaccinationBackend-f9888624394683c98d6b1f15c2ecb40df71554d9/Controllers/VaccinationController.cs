﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VaccinationBackend.Common.Entities;
using VaccinationBackend.DataBase;
using VaccinationBackend.Services;

namespace VaccinationBackend.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class VaccinationController : ControllerBase
    {
        private readonly ILogger<VaccinationController> _logger;
        private ApplicationDbContext _dbContext;

        public VaccinationController(ILogger<VaccinationController> logger,
            VaccinationService vaccinationServices, ApplicationDbContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
        }

        [HttpPost(Name = "CreateVaccination")]
        public IActionResult Add([FromBody] Vaccination vaccination)
        {
            try
            {
                // Validierung des Tokens und Extraktion der User-ID
                var userIdClaim = User.FindFirst("Uid")?.Value;
                if (string.IsNullOrEmpty(userIdClaim) || !int.TryParse(userIdClaim, out var userId))
                {
                    return Unauthorized(new { message = "Invalid or missing user ID in token." });
                }

                // Abrufen des Benutzers aus der Datenbank
                var user = _dbContext.Users.AsNoTracking().FirstOrDefault(u => u.Id == userId);
                if (user == null)
                {
                    return NotFound(new { message = "User not found." });
                }

                // Validierung des Impfungsobjekts
                if (vaccination == null)
                {
                    return BadRequest(new { message = "Invalid vaccination data provided." });
                }

                // Verknüpfen der User-Daten mit der Impfung
                vaccination.UserId = userId;
                vaccination.User = user;

                // Hinzufügen der Impfung zur Datenbank
                _dbContext.Vaccinations.Add(vaccination);
                _dbContext.SaveChanges();

                // Entfernen zyklischer Referenzen
                vaccination.User.Vaccinations = null;

                return Ok(vaccination);
            }
            catch (Exception ex)
            {
                // Logging der Exception für Debugging-Zwecke
                Console.Error.WriteLine($"Error adding vaccination: {ex.Message}");
                Console.Error.WriteLine($"StackTrace: {ex.StackTrace}");

                return StatusCode(500, new { message = "An internal error occurred. Please try again later." });
            }
        }


        [HttpGet("{userId}", Name = "GetVaccinations")]
        public IActionResult GetVaccinations(int userId)
        {
            try
            {
                // Loggen des Benutzerabrufs
                var user = _dbContext.Users.AsNoTracking().FirstOrDefault(u => u.Id == userId);
                if (user == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                // Loggen der Impfdaten
                var vaccinations = _dbContext.Vaccinations
                    .AsNoTracking()
                    .Include(v => v.Vaccine)
                    .Include(v => v.User)
                    .Where(v => v.UserId == userId)
                    .ToList();

                if (!vaccinations.Any())
                {
                    return NotFound(new { message = "No vaccinations found for this user." });
                }

                return Ok(vaccinations);
            }
            catch (Exception ex)
            {
                // Detailliertes Logging
                Console.Error.WriteLine($"Error in GetVaccinations: {ex}");
                return StatusCode(500, new { message = ex.Message });
            }
        }



        // Get a specific vaccination by Vaccination-ID
        [HttpGet("vaccination/{id}", Name = "GetVaccinationById")]
        public IActionResult Get(int id)
        {
            var userId = -1;
            try
            {
                // Extrahiere die Benutzer-ID aus dem Token
                userId = int.Parse(User.FindFirst("Uid")?.Value ?? string.Empty);
            }
            catch (Exception)
            {
                return BadRequest("Token invalid");
            }

            // Hole die Impfung basierend auf der ID und UserId
            //var vaccination = _dbContext.Vaccinations.FirstOrDefault(v => v.Id == id);
            var vaccination = _dbContext.Vaccinations.Include(v => v.Vaccine).FirstOrDefault(v => v.Id == id);

            if (vaccination == null)
            {
                return NotFound();
            }

            if (vaccination.Vaccine != null)            
                vaccination.Vaccine.Vaccinations = null;
            

            return Ok(vaccination);
        }

        // Update a specific vaccination by ID
        [HttpPut("{id}", Name = "UpdateVaccination")]
        public IActionResult Update(int id, Vaccination vaccination)
        {
            var userId = -1;
            try
            {
                userId = int.Parse(User.FindFirst("Uid")?.Value ?? string.Empty);
            }
            catch (Exception)
            {
                return BadRequest("Token invalid");
            }

            if (id != vaccination.Id)
            {
                return BadRequest("Vaccination ID mismatch");
            }

            var existingVaccination = _dbContext.Vaccinations.AsNoTracking().FirstOrDefault(v => v.Id == id);
            if (existingVaccination == null)
            {
                return NotFound();
            }
            var user = _dbContext.Users.Include(u => u.Vaccinations).AsNoTracking().FirstOrDefault(u => u.Id == userId);
            if (user == null || !user.Vaccinations.Any(v => v.Id == id))
            {
                return BadRequest("Vaccination does not belong to user");
            }
            _dbContext.Entry(vaccination).State = EntityState.Modified;
            _dbContext.SaveChanges();

            return Ok();
          
        }

        // Delete a specific vaccination by ID
        [HttpDelete("{id}", Name = "DeleteVaccination")]
        public IActionResult Delete(int id, Vaccination vaccination)
        {
            var userId = -1;
            try
            {
                userId = int.Parse(User.FindFirst("Uid")?.Value ?? string.Empty);
            }
            catch (Exception)
            {
                return BadRequest("Token invalid");
            }

            if (id != vaccination.Id)
            {
                return BadRequest("Vaccination ID mismatch");
            }

            var existingVaccination = _dbContext.Vaccinations.AsNoTracking().FirstOrDefault(v => v.Id == id);
            if (existingVaccination == null)
            {
                return NotFound();
            }
            var user = _dbContext.Users.Include(u => u.Vaccinations).AsNoTracking().FirstOrDefault(u => u.Id == userId);
            if (user == null || !user.Vaccinations.Any(v => v.Id == id))
            {
                return BadRequest("Vaccination does not belong to user");
            }

            _dbContext.Vaccinations.Remove(vaccination);
            _dbContext.SaveChanges();

            return Ok();
        }


    }
}
