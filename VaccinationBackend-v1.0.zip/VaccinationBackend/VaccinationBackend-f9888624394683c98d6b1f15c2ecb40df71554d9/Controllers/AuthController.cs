﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VaccinationBackend.Services;
using VaccinationBackend.Common.Entities;

namespace VaccinationBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly JwtService _jwtService;
        private readonly UserService _userService;

        public AuthController(JwtService jwtService, UserService userService)
        {
            _jwtService = jwtService;
            _userService = userService;
        }

        // Registrierung mit LoginRequest
        [AllowAnonymous]
        [HttpPost("register")]
        public IActionResult Register([FromBody] LoginRequest registerRequest)
        {
            if (_userService.Register(registerRequest.Email, registerRequest.Password))
            {
                return Ok(new { message = "User registered successfully." });
            }

            return BadRequest(new { message = "Email already taken." });
        }

        // Login mit LoginRequest
        [AllowAnonymous]
        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest loginRequest)
        {
            var user = _userService.Authenticate(loginRequest.Email, loginRequest.Password);
            if (user != null)
            {
                var token = _jwtService.GenerateToken(user.Email, user.Id);

                return Ok(token);
            }

            return Unauthorized();
        }
    }
}
