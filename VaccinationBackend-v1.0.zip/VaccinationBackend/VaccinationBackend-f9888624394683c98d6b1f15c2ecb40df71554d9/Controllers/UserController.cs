﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using VaccinationBackend.Common.Entities;
using VaccinationBackend.DataBase;

namespace VaccinationBackend.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;

        public UserController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        // Create or update the profile of the logged-in user
        [HttpPost]
        public IActionResult CreateOrUpdateProfile([FromBody] User userData)
        {
            var userId = int.Parse(User.FindFirst("Uid")?.Value ?? "0"); // User ID aus Token

            var user = _dbContext.Users.FirstOrDefault(u => u.Id == userId);

            if (user == null)
            {
                return NotFound(new { message = "User not found" });
            }

            // Aktualisiere die Benutzerinformationen
            user.FirstName = userData.FirstName;
            user.LastName = userData.LastName;
            user.Street = userData.Street;
            user.HouseNumber = userData.HouseNumber;
            user.ZipCode = userData.ZipCode;
            user.City = userData.City;
            user.PhoneNumber = userData.PhoneNumber;
            user.HealthInsurance = userData.HealthInsurance;
            user.InsuranceType = userData.InsuranceType;

            _dbContext.SaveChanges();
            return Ok(user);
        }

        // Get the profile of the logged-in user
        [HttpGet(Name = "GetUserProfile")]
        public IActionResult GetUserProfile()
        {
            var userId = -1;
            try
            {
                userId = int.Parse(User.FindFirst("Uid")?.Value ?? string.Empty);
            }
            catch (Exception)
            {
                return BadRequest("Token invalid");
            }
            var user = _dbContext.Users.Include(u => u.Vaccinations).ThenInclude(v => v.Vaccine).FirstOrDefault(u => u.Id == userId);

            if (user == null)
                return NotFound("User not found");

            foreach (var vaccination in user.Vaccinations)
            {
                vaccination.User = null;
                if (vaccination.Vaccine != null)
                    vaccination.Vaccine.Vaccinations = null;
            }

            return Ok(new
            {
                user
            });
        }

        [HttpPut("{id}")]
        public IActionResult UpdateProfileById(int id, [FromBody] User userData)
        {
            // Validierung: Sicherstellen, dass Eingabedaten vorhanden sind
            if (userData == null || string.IsNullOrWhiteSpace(userData.FirstName) || string.IsNullOrWhiteSpace(userData.LastName))
            {
                return BadRequest(new { message = "Invalid user data" });
            }

            // Benutzer anhand der ID finden
            var user = _dbContext.Users.Include(u => u.Vaccinations).ThenInclude(v => v.Vaccine).FirstOrDefault(u => u.Id == id);

            if (user == null)
            {
                return NotFound(new { message = "User profile not found" });
            }

            // Aktualisieren der Benutzerdaten
            user.FirstName = userData.FirstName;
            user.LastName = userData.LastName;
            user.Street = userData.Street;
            user.HouseNumber = userData.HouseNumber;
            user.ZipCode = userData.ZipCode;
            user.City = userData.City;
            user.PhoneNumber = userData.PhoneNumber;
            user.HealthInsurance = userData.HealthInsurance;
            user.InsuranceType = userData.InsuranceType;

            // Verknüpfte Daten handhaben (z. B. Impfungen)
            foreach (var vaccination in user.Vaccinations)
            {
                vaccination.User = null;
                if (vaccination.Vaccine != null)
                {
                    vaccination.Vaccine.Vaccinations = null;
                }
            }

            // Änderungen speichern
            _dbContext.SaveChanges();

            // Rückgabe des aktualisierten Benutzers
            return Ok(new
            {
                user
            });
        }


        [HttpDelete("{id}")]
        public IActionResult DeleteProfileById(int id)
        {
            // Benutzer anhand der ID finden
            var user = _dbContext.Users.Include(u => u.Vaccinations).ThenInclude(v => v.Vaccine).FirstOrDefault(u => u.Id == id);

            if (user == null)
            {
                return NotFound(new { message = "User profile not found" });
            }

            // Optional: Überprüfung, ob der Löschende berechtigt ist
            var requesterId = int.Parse(User.FindFirst("Uid")?.Value ?? "0");
            if (requesterId != id && !User.IsInRole("Admin"))
            {
                return Forbid(); // Nur der Benutzer selbst oder ein Admin darf löschen
            }

            // Option 1: Hard Delete (komplette Löschung)
            _dbContext.Users.Remove(user);

            _dbContext.SaveChanges();

            // Verknüpfte Daten bereinigen, falls nötig
            foreach (var vaccination in user.Vaccinations)
            {
                vaccination.User = null;
                if (vaccination.Vaccine != null)
                {
                    vaccination.Vaccine.Vaccinations = null;
                }
            }

            // Rückmeldung
            return Ok(new { message = "User profile deleted successfully" });
        }

    }
}
