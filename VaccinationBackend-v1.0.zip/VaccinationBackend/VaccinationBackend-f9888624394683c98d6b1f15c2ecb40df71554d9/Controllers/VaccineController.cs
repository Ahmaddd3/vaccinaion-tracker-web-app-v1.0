﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using VaccinationBackend.Common.Entities;
using VaccinationBackend.DataBase;
using VaccinationBackend.Services;

namespace VaccinationBackend.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class VaccineController : ControllerBase
    {
        private readonly ILogger<VaccineController> _logger;
        private ApplicationDbContext _dbContext;

        public VaccineController(ILogger<VaccineController> logger,
            VaccineService vaccineServices, ApplicationDbContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
        }

        [HttpPost(Name = "AddVaccine")]
        public IActionResult Add(Vaccine vaccine)
        {
            try
            {
                var userId = int.Parse(User.FindFirst("Uid")?.Value ?? "0");

                var user = _dbContext.Users.FirstOrDefault(u => u.Id == userId);
                if (user == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                 vaccine.UserId = userId; 
                 vaccine.User = user;
                _dbContext.Vaccines.Add(vaccine);
                _dbContext.SaveChanges();

                if (vaccine.User != null)
                    vaccine.User.Vaccinations = null;

                return Ok(vaccine);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }


        // Get all vaccines
        [HttpGet(Name = "GetAllVaccines")]
        public IActionResult GetVaccines()
        {
            return Ok(_dbContext.Vaccines);
        }

        // Get all vaccines for a specific user
        [HttpGet("{userId}", Name = "GetVaccines")]
        public IActionResult GetVaccines(int userId)
        {
            try
            {
                var user = _dbContext.Users.FirstOrDefault(u => u.Id == userId);
                if (user == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var vaccines = _dbContext.Vaccines
                    .Where(v => v.UserId == userId)
                    .ToList();

                if (vaccines == null || !vaccines.Any())
                {
                    return NotFound(new { message = "No vaccines found for this user." });
                }

                return Ok(vaccines);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }


        // Get a specific vaccine by Vaccine-ID 
        [HttpGet("vaccine/{id}", Name = "GetVaccineById")]
        public IActionResult Get(int id)
        {
            var userId = -1;
            try
            {
                // Extrahiere die Benutzer-ID aus dem Token
                userId = int.Parse(User.FindFirst("uid")?.Value ?? string.Empty);
            }
            catch (Exception)
            {
                return BadRequest("Token invalid");
            }

            // Suche den Impfstoff basierend auf der ID und UserId
            var vaccine = _dbContext.Vaccines
                                    .FirstOrDefault(v => v.UserId == id);

            if (vaccine == null)
            {
                return NotFound();
            }

            return Ok(vaccine);
        }


        // Update a specific vaccine by ID
        [HttpPut("{id}", Name = "UpdateVaccine")]
        public IActionResult Update(int id, Vaccine updatedVaccine)
        {
            var userId = -1;
            try
            {
                userId = int.Parse(User.FindFirst("Uid")?.Value ?? string.Empty);  // Extrahiere UserID aus dem Token
            }
            catch (Exception)
            {
                return BadRequest("Token invalid");
            }

            if (id != updatedVaccine.Id)
            {
                return BadRequest("Vaccine ID mismatch");
            }

            // Hole den Impfstoff, um sicherzustellen, dass er existiert
            var vaccine = _dbContext.Vaccines.FirstOrDefault(v => v.Id == id);
            if (vaccine == null)
            {
                return NotFound();
            }

            // Aktualisiere die Eigenschaften des Impfstoffs
            vaccine = updatedVaccine;

            // Speichere die Änderungen in der Datenbank
            _dbContext.SaveChanges();

            return Ok(vaccine);
        }

        // Delete a specific vaccine by ID
        [HttpDelete("{id}", Name = "DeleteVaccine")]
        public IActionResult Delete(int id)
        {
            var userId = -1;
            try
            {
                userId = int.Parse(User.FindFirst("Uid")?.Value ?? string.Empty);  // Extrahiere UserID aus dem Token
            }
            catch (Exception)
            {
                return BadRequest("Token invalid");
            }

            // Hole den Impfstoff, um sicherzustellen, dass er existiert
            var vaccine = _dbContext.Vaccines.FirstOrDefault(v => v.Id == id);
            if (vaccine == null)
            {
                return NotFound();
            }

            _dbContext.Vaccines.Remove(vaccine);
            _dbContext.SaveChanges();

            return Ok();
        }

    }
}
