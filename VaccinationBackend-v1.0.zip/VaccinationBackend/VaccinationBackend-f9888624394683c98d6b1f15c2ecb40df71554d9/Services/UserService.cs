﻿using System.Security.Cryptography;
using System.Text;
using VaccinationBackend.Common.Entities;
using VaccinationBackend.DataBase;

public class UserService
{
    private readonly ApplicationDbContext _dbContext;

    public UserService(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public bool Register(string email, string password)
    {
        if (_dbContext.Users.Any(u => u.Email == email))
            return false;

        var hashedPassword = HashPassword(password);
        _dbContext.Users.Add(new User { Email = email, PasswordHash = hashedPassword });
        _dbContext.SaveChanges();
        return true;
    }

    public User? Authenticate(string email, string password)
    {
        var user = _dbContext.Users.FirstOrDefault(u => u.Email == email);
        if (user == null || user.PasswordHash != HashPassword(password))
            return null;

        return user;
    }

    private string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(hashedBytes);
    }
}
