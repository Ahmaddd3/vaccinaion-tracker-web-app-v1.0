﻿using VaccinationBackend.Common.Entities;

namespace VaccinationBackend.Services
{
    public class VaccinationService
    {
        public List<Vaccination> Vaccinations { get; set; } = new List<Vaccination>();
    }
}
