﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace VaccinationBackend.Services
{
    public class JwtService
    {
        private readonly string _key;
        private readonly string _issuer;

        public JwtService(IConfiguration config)
        {
            _key = config["Jwt:Key"] ?? string.Empty;
            _issuer = config["Jwt:Issuer"] ?? string.Empty;
        }
        public class TokenResponse 
        { 
            public required string Token { get; set; }
            public int Uid { get; set; }
        
        }

        public TokenResponse GenerateToken(string email, int id)
        {
            var claims = new[] 
            {
                new Claim(JwtRegisteredClaimNames.Sub, email),
                new Claim("Uid", id.ToString()),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_key));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _issuer,
                audience: _issuer,
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(30),
                signingCredentials: creds);
            var tokenString = new JwtSecurityTokenHandler().WriteToken(token);
            return new TokenResponse { Token = tokenString, Uid = id };

        }


        internal object GenerateToken(string username)
        {
            throw new NotImplementedException();
        }
    }
}
