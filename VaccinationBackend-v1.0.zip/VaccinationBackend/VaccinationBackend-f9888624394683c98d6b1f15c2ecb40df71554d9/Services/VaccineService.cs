﻿using VaccinationBackend.Common.Entities;

namespace VaccinationBackend.Services
{
    public class VaccineService
    {
        public List<Vaccine> Vaccines { get; set; } = new List<Vaccine>();
    }
}

