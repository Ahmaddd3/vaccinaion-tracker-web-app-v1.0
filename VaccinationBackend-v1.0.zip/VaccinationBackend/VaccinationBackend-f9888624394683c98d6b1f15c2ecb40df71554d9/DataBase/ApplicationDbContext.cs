﻿using Microsoft.EntityFrameworkCore;
using VaccinationBackend.Common.Entities;

namespace VaccinationBackend.DataBase
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Vaccination> Vaccinations { get; set; } = null!;
        public DbSet<Vaccine> Vaccines { get; set; } = null!;

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Define 1:n relationship between User and Vaccination
            modelBuilder.Entity<Vaccination>()
                .HasOne(v => v.User)
                .WithMany(u => u.Vaccinations)
                .HasForeignKey(v => v.UserId)
                .OnDelete(DeleteBehavior.Cascade);


            // Define 1:n relationship between Vaccine and Vaccination
            modelBuilder.Entity<Vaccination>()
                .HasOne(v => v.Vaccine)
                .WithMany(v => v.Vaccinations)
                .HasForeignKey(v => v.VaccineId);


            base.OnModelCreating(modelBuilder);
        }
    }
}
