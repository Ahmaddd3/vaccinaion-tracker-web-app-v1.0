﻿using VaccinationBackend.Common.Enums;

namespace VaccinationBackend.Common.Entities
{
    public class User
    {
        public int Id { get; set; }
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string? FirstName { get; set; } = string.Empty;
        public string? LastName { get; set; } = string.Empty;
        public string? Street { get; set; } = string.Empty;
        public string? HouseNumber { get; set; } = string.Empty;
        public string? ZipCode { get; set; } = string.Empty;
        public string? City { get; set; } = string.Empty;
        public string? PhoneNumber { get; set; } = string.Empty;
        public string? HealthInsurance { get; set; } = string.Empty;
        public InsuranceTypes? InsuranceType { get; set; }

        // Navigation property for Vaccinations
        public IEnumerable<Vaccination> Vaccinations { get; set; } = new List<Vaccination>();

    }

}
