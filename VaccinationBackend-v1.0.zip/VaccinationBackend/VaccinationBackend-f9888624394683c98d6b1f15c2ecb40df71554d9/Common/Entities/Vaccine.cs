﻿using VaccinationBackend.Common.Enums;

namespace VaccinationBackend.Common.Entities
{
    public class Vaccine
    {
        public int Id { get; set; } // Automatisch generierte ID
        public string Name { get; set; } = string.Empty; // Name der Impfung
        public string Producer { get; set; } = string.Empty;
        public VaccineTypes? VaccineType { get; set; }
        public string? VaccinationType { get; set; } = string.Empty;
        public int? RequiredDoses { get; set; }

        // Navigation property for Vaccinations
        public ICollection<Vaccination>? Vaccinations { get; set; } = new List<Vaccination>();

        // Navigationseigenschaft für den Benutzer
        public int UserId { get; set; }
        public required User User { get; set; } // Navigation zu User


    }


}