﻿using System;
using Microsoft.EntityFrameworkCore;

namespace VaccinationBackend.Common.Entities
{
    // Klasse für Vaccination: Allgemeine Informationen zur Impfung
    public class Vaccination
    {

        public int Id { get; set; }
        public DateTime VaccinationDate { get; set; }
        public string DoctorName { get; set; } = string.Empty;
        public DateTime? BoosterDate { get; set; }
        public string? SerialNumber { get; set; } = string.Empty;
        public DateTime? ManufacturingDate { get; set; }

        // Navigation property for User
        public int UserId { get; set; }
        public User? User { get; set; } = null!;

        // Navigation property for Vaccine
        public int VaccineId { get; set; }
        public Vaccine? Vaccine { get; set; } = null!;

    }

}