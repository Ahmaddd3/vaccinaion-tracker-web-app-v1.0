﻿namespace VaccinationBackend.Common.Enums
{
    public enum VaccineTypes
    {
        mRNA,
        Vector,
        ProteinSubunit,
        InactivatedVirus
    }
}
