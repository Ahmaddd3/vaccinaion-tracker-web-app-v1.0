﻿namespace VaccinationBackend.Common.Enums
{
    public enum InsuranceTypes
    {
        PrivateInsurance = 0,
        Government = 1
    }
}
